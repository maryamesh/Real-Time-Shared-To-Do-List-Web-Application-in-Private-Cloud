import eventlet
eventlet.monkey_patch()

from flask import Flask, render_template
from flask_socketio import SocketIO, emit
from werkzeug.middleware.proxy_fix import ProxyFix
import redis
import os
import json
import uuid

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
app.config['DATA_FOLDER'] = '/app/data'
# Add this immediately after app creation to trust proxy headers
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Redis connection
REDIS_HOST = os.getenv("REDIS_HOST", "redis")
redis_client = redis.StrictRedis(host=REDIS_HOST, port=6379, decode_responses=True)

# Shared pub/sub via Redis
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode='eventlet',
    message_queue=f'redis://{REDIS_HOST}:6379',
    transports=['websocket', 'polling']  # Added transports parameter here
    path='/socket.io'
)

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    tasks = redis_client.lrange("tasks", 0, -1)
    parsed_tasks = [json.loads(task) for task in tasks]
    emit('update_tasks', parsed_tasks)

@socketio.on('add_task')
def handle_add_task(data):
    task_text = data.get('text', '').strip()
    if not task_text:
        return
    task = {
        'id': str(uuid.uuid4()),
        'text': task_text,
        'completed': False
    }
    redis_client.rpush("tasks", json.dumps(task))
    broadcast_tasks()

@socketio.on('edit_task')
def handle_edit_task(data):
    task_id = data.get('id')
    new_text = data.get('text', '').strip()
    if not new_text:
        return
    update_task(task_id, lambda t: t.update({'text': new_text}))
    broadcast_tasks()

@socketio.on('delete_task')
def handle_delete_task(data):
    task_id = data.get('id')
    remove_task(task_id)
    broadcast_tasks()

@socketio.on('toggle_complete_task')
def handle_toggle_complete_task(data):
    task_id = data.get('id')
    update_task(task_id, lambda t: t.update({'completed': not t['completed']}))
    broadcast_tasks()

@socketio.on('clear_all_tasks')
def handle_clear_all():
    redis_client.delete("tasks")
    broadcast_tasks()

@socketio.on('clear_completed_tasks')
def handle_clear_completed():
    tasks = redis_client.lrange("tasks", 0, -1)
    redis_client.delete("tasks")
    for task_json in tasks:
        task = json.loads(task_json)
        if not task['completed']:
            redis_client.rpush("tasks", json.dumps(task))
    broadcast_tasks()

def update_task(task_id, update_func):
    tasks = redis_client.lrange("tasks", 0, -1)
    redis_client.delete("tasks")
    for task_json in tasks:
        task = json.loads(task_json)
        if task['id'] == task_id:
            update_func(task)
        redis_client.rpush("tasks", json.dumps(task))

def remove_task(task_id):
    tasks = redis_client.lrange("tasks", 0, -1)
    redis_client.delete("tasks")
    for task_json in tasks:
        task = json.loads(task_json)
        if task['id'] != task_id:
            redis_client.rpush("tasks", json.dumps(task))

def broadcast_tasks():
    tasks = redis_client.lrange("tasks", 0, -1)
    socketio.emit('update_tasks', [json.loads(t) for t in tasks])

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
