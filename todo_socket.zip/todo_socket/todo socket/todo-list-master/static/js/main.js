// Elements
const tasksList = document.querySelector("#tasks-list")
const addTaskForm = document.querySelector("form#add-task")
const addTaskInput = document.querySelector("#add-task-input")
const clearAllTasksBtn = document.querySelector("button#clear-all-tasks")

// Socket.IO client setup
const socket = io('http://172.20.10.4', {  // replace with your VM IP or domain
  path: '/socket.io',
  transports: ['websocket', 'polling']
});

// Task list (updated by server events)
let list = []

/**
 * Show all tasks in the page
 */
function showTasksList() {
  tasksList.innerHTML = ""

  if (list.length === 0) {
    clearAllTasksBtn.disabled = true

    const element = String.raw`
      <div class="ui icon warning message">
        <i class="inbox icon"></i>
        <div class="content">
          <div class="header">You have nothing task today!</div>
          <div>Enter your tasks today above.</div>
        </div>
      </div>
    `
    tasksList.style.border = "none"
    return tasksList.insertAdjacentHTML("beforeend", element)
  }

  clearAllTasksBtn.disabled = false
  tasksList.style.border = "1px solid rgba(34,36,38,.15)"
  list.slice().reverse().forEach(task => {
    const element = String.raw`
      <li class="ui segment grid equal width">
        <div class="ui checkbox column">
          <input type="checkbox" ${task.completed ? "checked" : ""}>
          <label>${task.text}</label>
        </div>
        <div class="column">
          <i data-id="${task.id}" class="edit outline icon"></i>
          <i data-id="${task.id}" class="trash alternate outline remove icon"></i>
        </div>
      </li>
    `
    tasksList.insertAdjacentHTML("beforeend", element)
  })

  // Add event listeners for edit icons
  document.querySelectorAll(`li i.edit`).forEach(item => {
    item.addEventListener("click", e => {
      e.stopPropagation()
      showEditModal(+e.target.dataset.id)
    })
  })

  // Add event listeners for delete icons
  document.querySelectorAll(`li i.trash`).forEach(item => {
    item.addEventListener("click", e => {
      e.stopPropagation()
      showRemoveModal(+e.target.dataset.id)
    })
  })
}

/**
 * Add new task - send to server
 */
function addTask(event) {
  event.preventDefault()

  const taskText = addTaskInput.value.trim()
  if (taskText.length === 0) {
    addTaskInput.value = ""
    return
  }

  socket.emit("add_task", { text: taskText })
  addTaskInput.value = ""
}

/**
 * Edit task - send to server
 */
function editTask(id) {
  const taskText = document.querySelector("#task-text").value.trim()
  if (taskText.length === 0) return

  socket.emit("edit_task", { id, text: taskText })
  $("#edit-modal.modal").modal("hide")
}

/**
 * Remove task - send to server
 */
function removeTask(id) {
  socket.emit("delete_task", { id })
  $("#remove-modal.modal").modal("hide")
}

/**
 * Toggle complete - send to server
 */
function completeTask(id) {
  socket.emit("toggle_complete_task", { id })
}

/**
 * Clear all tasks - send to server
 */
function clearAllTasks() {
  socket.emit("clear_all_tasks")
  $("#clear-all-tasks-modal.modal").modal("hide")
}

/**
 * Clear completed tasks - send to server
 */
function clearCompleteTasks() {
  socket.emit("clear_completed_tasks")
  $("#clear-completed-tasks-modal.modal").modal("hide")
}

/**
 * Show edit modal and populate fields
 */
function showEditModal(id) {
  const task = list.find(t => t.id === id)
  if (!task) return

  document.querySelector("#edit-modal .content #task-id").value = id
  document.querySelector("#edit-modal .content #task-text").value = task.text.trim()

  // Remove previous listeners to avoid duplicates
  const updateBtn = document.querySelector("#update-button")
  const newUpdateBtn = updateBtn.cloneNode(true)
  updateBtn.parentNode.replaceChild(newUpdateBtn, updateBtn)

  newUpdateBtn.addEventListener("click", () => editTask(id))

  $("#edit-modal.modal").modal("show")
}

/**
 * Show remove modal
 */
function showRemoveModal(id) {
  // Remove previous listeners to avoid duplicates
  const removeBtn = document.querySelector("#remove-button")
  const newRemoveBtn = removeBtn.cloneNode(true)
  removeBtn.parentNode.replaceChild(newRemoveBtn, removeBtn)

  newRemoveBtn.addEventListener("click", () => removeTask(id))

  $("#remove-modal.modal").modal("show")
}

/**
 * Show clear all tasks modal
 */
function showClearAllTasksModal() {
  if (list.length > 0) {
    return $("#clear-all-tasks-modal.modal").modal("show")
  }

  new Noty({
    type: "error",
    text: '<i class="close icon"></i> There is no task to remove.',
    layout: "bottomRight",
    timeout: 2000,
    progressBar: true,
    closeWith: ["click"],
    theme: "metroui",
  }).show()
}

/**
 * Show notification
 */
function showNotification(type, text) {
  new Noty({
    type,
    text: `<i class="check icon"></i> ${text}`,
    layout: "bottomRight",
    timeout: 2000,
    progressBar: true,
    closeWith: ["click"],
    theme: "metroui",
  }).show()
}

// Listen for task list updates from server
socket.on("update_tasks", tasks => {
  list = tasks
  showTasksList()
})

// Checkbox change event (toggle complete)
tasksList.addEventListener("change", e => {
  if (e.target.type === "checkbox") {
    const id = e.target.closest("li").querySelector("i.edit").dataset.id
    completeTask(id)
  }
})

// Clear completed tasks button handler
document.querySelector("#clear-completed-tasks-modal .ui.positive").addEventListener("click", clearCompleteTasks)

// Event listeners
addTaskForm.addEventListener("submit", addTask)
window.addEventListener("load", () => addTaskInput.focus())

showTasksList()
